#!/usr/bin/env python3

from taller2.srv import *
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
import numpy as np
import time


def turtle_bot_playerFUn(req):
	pub = rospy.Publisher('robot_cmdVel', Twist, queue_size=10)
	rate = rospy.Rate(10)  # 10hz
	message = Twist()
	#ruta
	f=open(req.name,'r')
	datos=f.read()
	lista_nueva=[]
	for i in datos:
		if i!='\n':
			lista_nueva.append(i)
	vel_lineal= float(lista_nueva[0]+lista_nueva[1])
	vel_angular= float(lista_nueva[2]+lista_nueva[3])
	
	for j in range(5,len(lista_nueva)-2):
		if lista_nueva[j] == 's':
		    message.linear.x = -vel_lineal
		    message.linear.y = 0
		    message.linear.z = 0
		    message.angular.x = 0
		    message.angular.y = 0
		    message.angular.z = 0	    
		    print(message)
		    pub.publish(message)

		elif lista_nueva[j] =='w':
		    message.linear.x = vel_lineal
		    message.linear.y = 0
		    message.linear.z = 0
		    message.angular.x = 0
		    message.angular.y = 0
		    message.angular.z = 0
		    print(message)
		    pub.publish(message)

		elif lista_nueva[j] == 'a':
		    message.angular.x = 0
		    message.angular.y = 0
		    message.angular.z = vel_angular
		    message.linear.x = 0
		    message.linear.y = 0
		    message.linear.z = 0
		    print(message)
		    pub.publish(message)

		elif lista_nueva[j] == 'd':
		    message.angular.x = 0
		    message.angular.y = 0
		    message.angular.z = -vel_angular
		    message.linear.x = 0
		    message.linear.y = 0
		    message.linear.z = 0		    
		    print(message)
		    pub.publish(message)
		else:
		    message.linear.x = 0
		    message.linear.y = 0
		    message.linear.z = 0
		    message.angular.x = 0
		    message.angular.y = 0
		    message.angular.z = 0
		    print(message)
		    pub.publish(message)
		time.sleep(0.5)
	res='Proceso Finalizado'
	return res

def main_server():

    	
	rospy.init_node('turtle_bot_player')


	s = rospy.Service('turtle_bot_player_node', turtle_bot_player, turtle_bot_playerFUn)
	print ("Esperando peticion...")
	rospy.spin()
	print ("\nCerrando servidor")
if __name__ == "__main__":
    main_server()
