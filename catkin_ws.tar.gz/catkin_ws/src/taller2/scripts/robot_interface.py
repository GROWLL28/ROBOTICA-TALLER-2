#!/usr/bin/env python3
from tkinter import Tk, Frame, Button, Label, ttk
from tkinter import *
from matplotlib.figure import Figure
import numpy as np
import shutil
import matplotlib.pyplot as plt
import pyautogui
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import matplotlib.animation as animation
import rospy
import tty
import sys
import termios
import keyboard
from std_msgs.msg import String
from geometry_msgs.msg import Twist

x_pos=[0]
y_pos=[0]
tetha=[0]
r=4
L=20
F=True

phir=[0,np.pi]
phil=[0,np.pi]

dt=0.1
def callback(msg):
	
	Vel = round(msg.linear.x,2)
	Ang = round(msg.angular.z,2)
	

	if Vel==0 and Ang==0:
		Vr=phir[0]
		Vl=phil[0]
	elif Vel==0 and Ang>0:
		Vr=phir[1]
		Vl=-phil[1]
	elif Vel==0 and Ang<0:
		Vr=-phir[1]
		Vl=phil[1]
	elif  Vel>0 and Ang==0:
		Vr=phir[1]
		Vl=phil[1]	
	elif  Vel<0 and Ang==0:
		Vr=-phir[1]
		Vl=-phil[1]			
		
	x_pos.append(x_pos[-1]+0.5*(Vr+Vl)+np.cos(tetha[-1])*dt)
	y_pos.append(y_pos[-1]+0.5*(Vr+Vl)+np.sin(tetha[-1])*dt)
	tetha.append(tetha[-1]*(1/L)*(Vr-Vl)*dt)
	
	print(".-------------------------")
	print("x_pos",x_pos[-1])		
	print("y_pos",y_pos[-1])	


def robot_interface():

	rospy.init_node('robot_interface', anonymous=True)
	rospy.Subscriber('robot_cmdVel', Twist, callback)

def animate(i):
	ax.clear()
	ax.plot(x_pos,y_pos)

def guardar():
	print(nom.get())
	f=open('lista.txt','r')
	datos=f.read()
	lista_nueva=[]
	for i in datos:
		if i!='\n':
			lista_nueva.append(i)
	recorrido = []
	recorrido.append(lista_nueva[0]+lista_nueva[1])
	recorrido.append(lista_nueva[2]+lista_nueva[3])
	for j in range (2,len(lista_nueva)-2):
		recorrido.append(lista_nueva[j+2])
	print(recorrido)
	np.savetxt(nom.get()+'.txt',recorrido,fmt="%s")



def guardar_imagen():
	screenshot = pyautogui.screenshot()
	# Guardar imagen.
	screenshot.save('Camino.png')
	
#Creacion de ventana de interfaz
ventana = Tk()
ventana.geometry('720x340')
ventana.wm_title('Turtle_bot_interface')
ventana.minsize(width=900, height=600)

#Color de la ventana
e1=Label(ventana,text="Nombre archivo TXT: ",fg="red" )
e1.pack(pady=5,side="left",expand=1)

nom=Entry(ventana)
nom1=str(nom)
nom.pack(pady=5,side="left",expand=1)
print(nom1)

frame = Frame(ventana, bg='#D7DBDD')
frame.pack(expand=1, fill='both')

fig, ax = plt.subplots(facecolor='#FFFFFF')
plt.title("Interfaz", color='black', size=20)


canvas = FigureCanvasTkAgg(plt.gcf(), master=frame)
canvas.get_tk_widget().pack(padx=5, pady=5, expand=1, fill='both')

ani=animation.FuncAnimation(plt.gcf(),animate,interval=1000)
canvas.draw()

Button(frame, text="Guardar TXT",width=15,fg="red",command=guardar).pack(pady=5,side="top",expand=1)
 
Button(frame, text="Guardar Imagen",width=15,fg="red",command=guardar_imagen).pack(pady=5,side="top",expand=1)
    
if __name__ == '__main__':
    robot_interface()
    ventana.mainloop()
