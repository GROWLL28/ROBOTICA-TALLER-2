#!/usr/bin/env python3
#se importan las librerías necesarias para el funcionamiento de este nodo. 
import rospy
import tty
import sys
import numpy as np
import termios
import keyboard
from std_msgs.msg import String
from geometry_msgs.msg import Twist


def robot_teleop(): #se define la función que publicará al tópico de la velocidad de turtle bot


	pub = rospy.Publisher('robot_cmdVel', Twist, queue_size=10) #declaramos la variable que publicará las velocidades
	rospy.init_node('robot_teleop', anonymous=True)  #inicializamos el nodo
	rate = rospy.Rate(10) #definimos la frecuencia de actualización

	filedescriptors = termios.tcgetattr(sys.stdin) 
	tty.setcbreak(sys.stdin)

	x = 0
	
	moveV = int(input("Indíqueme la velocidad lineal: \n")) #definimos la velocidad lineal como el valor de entrada definido por el 									   usuario
	anglV=  int(input("Indíqueme la velocidad angular: \n")) #definimos la velocidad angular como el valor de entrada definido por el 							           usuario

	Camino = [] #creamos la variable que guardaŕa las teclas oprimidas. Luego anexamos las velocidades que se definieron anteriormente
	Camino.append(moveV)
	Camino.append(anglV)

	while not rospy.is_shutdown(): #mientras que no se cierre la comunicación al tópico por el nodo, se irán publicando
					#los valores de las velocidades a través de un mensaje tipo Twist.

		message = Twist()
		message.linear.x = 0
		message.linear.y = 0
		message.linear.z = 0
		message.angular.x = 0
		message.angular.y = 0
		message.angular.z = 0
		pub.publish(message)

		x = sys.stdin.read(1)[0] #se realiza conversión de la tecla oprimida, para que sea tiipo string

		if x == "s":			#se ralizan condiciones para evaluar si la letra oprimida es alguna de las de manejo
						#(w,a,s,d). En caso de ser así, se efectíua el cambio en el tópico a través del nodo.
			message.linear.x = -moveV
			message.linear.y = 0
			message.linear.z = 0		
			pub.publish(message)

		elif x == "w":
			message.linear.x = moveV
			message.linear.y = 0
			message.linear.z = 0
			pub.publish(message)
			
		elif x == "a":
			message.angular.x = 0
			message.angular.y = 0
			message.angular.z = anglV		
			pub.publish(message)

		elif x == "d":
			message.angular.x = 0
			message.angular.y = 0
			message.angular.z = -anglV
			pub.publish(message)

		Camino.append(x) #se anexa cada tecla oprimida a la lista
		np.savetxt('lista.txt',Camino, fmt="%s") #se guarda la lista en un archivo.txt llamado "lista"
	
		print(Camino)
		rospy.loginfo(message) #se envía la actualización de las compenentes de las velocidades al tópico
		rate.sleep()

if __name__ == '__main__': #se compilan las funciones definidas en le main
	try:

		robot_teleop()
	except rospy.ROSInterruptException:
		pass
