
"use strict";

let player_srv = require('./player_srv.js')

module.exports = {
  player_srv: player_srv,
};
